__author__ = 'Heejun Kim, heejunk@email.unc.edu, Onyen = heejunk'

import codecs
import csv
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import RegexpTokenizer
tokenizer = RegexpTokenizer(r'\w+')

def cal_mutual_info(token, count_dic, pos, neg):
    N = count_dic["a"]+count_dic["b"]+count_dic["c"]+count_dic["d"]
    pos[token] = (count_dic["a"] / N) / ( (count_dic["a"]+count_dic["c"])/N * (count_dic["a"]+count_dic["c"])/N )
    neg[token] = (count_dic["b"] / N) / ( (count_dic["b"] + count_dic["d"]) / N * (count_dic["a"] + count_dic["b"]) / N)
    return pos, neg

def cal_chi(token, count_dic, chi):
    N = count_dic["a"]+count_dic["b"]+count_dic["c"]+count_dic["d"]
    chi[token] =  ( N * (count_dic["a"]*count_dic["d"] - count_dic["c"]*count_dic["b"] )**2 ) / \
                  ( (count_dic["a"]+count_dic["c"]) * (count_dic["b"]+count_dic["d"]) * (count_dic["a"]+count_dic["b"]) * (count_dic["c"]+count_dic["d"]) )
    return chi
loop = True
while (loop):
    training_file = input("Please type in input file name. File should be in csv format and saved in the same directory with this Python script: ")
    if ".csv" not in training_file:
        print("The file should be in csv format.")
    else:
        loop = False
loop = True
first = True
while(loop):
    try:
        if first == True :
            first = False
            data_file = codecs.open(training_file, "r", encoding="utf-8", errors = "replace")
            csv_reader = csv.reader(data_file)
        else :
            training_file = input("Please type in input file name. File should be in csv format and saved in the same directory with this Python script: ")
            data_file = codecs.open(training_file, "r", encoding="utf-8", errors = "replace")
            csv_reader = csv.reader(data_file)
        loop = False
    except :
        print("There is something wrong in the file. Try again.")

classes = list() 

unique_terms = dict()
tokens_in_documents = []

# set num to avoid to process the column names
num = 0
lines = []

for row in csv_reader:
    if num != 0 :
        lines.append(row)
        if row[2].rstrip() not in classes:
            classes.append(row[2].rstrip())
        tokens = tokenizer.tokenize(row[1].lower())
        filtered_tokens = [w for w in tokens if not w in stopwords.words('english')]
        unique_tokens = set(filtered_tokens)
        tokens_in_documents.append(unique_tokens)
        for token in unique_tokens:
            if token not in unique_terms :
                temp_dic = dict()
                temp_dic["a"] = 0
                temp_dic["b"] = 0
                temp_dic["c"] = 0
                temp_dic["d"] = 0
                unique_terms[token] = temp_dic
    num += 1

for term in unique_terms:
    num = 0
    for line in lines:
        filtered_tokens = tokens_in_documents[num]
        if line[2].rstrip() == classes[0]:
            if term in filtered_tokens:
                unique_terms[term]["a"] += 1
            else:
                unique_terms[term]["c"] += 1
        else:
            if term in filtered_tokens:
                unique_terms[term]["b"] += 1
            else:
                unique_terms[term]["d"] += 1
        num += 1

pos_mutual = dict()
neg_mutual = dict()

for term in unique_terms:
    pos_mutual, neg_mutual = cal_mutual_info(term, unique_terms[term], pos_mutual, neg_mutual)

chi_square = dict()

for term in unique_terms:
    chi_square = cal_chi(term, unique_terms[term], chi_square)

import operator

sorted_pos_mutual = sorted(pos_mutual.items(), key=operator.itemgetter(1))
sorted_pos_mutual.reverse()

out_brca = open("mi_"+str(classes[0]+".csv"),"wb")
for item in sorted_pos_mutual:
    out_line = str(item[0]) + "," + str(item[1]) + "\n"
    out_brca.write(out_line.encode("utf-8"))
out_brca.close()

sorted_skin_mutual = sorted(neg_mutual.items(), key=operator.itemgetter(1))
sorted_skin_mutual.reverse()

out_skincancer = open("mi_"+str(classes[1]+".csv"),"wb")
for item in sorted_skin_mutual:
    out_line = str(item[0]) + "," + str(item[1]) + "\n"
    out_skincancer.write(out_line.encode("utf-8"))
out_skincancer.close()

sorted_chi_square = sorted(chi_square.items(), key=operator.itemgetter(1))
sorted_chi_square.reverse()

out_chi = open("chi_square.csv","wb")
for item in sorted_chi_square:
    out_line = str(item[0]) + "," + str(item[1]) + "\n"
    out_chi.write(out_line.encode("utf-8"))
out_chi.close()


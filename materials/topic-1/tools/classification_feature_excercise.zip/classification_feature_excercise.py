__author__ = 'Heejun Kim, heejunk@email.unc.edu, Onyen = heejunk'

import codecs
import csv
import nltk

def filter_features(text, features):
    tokens = nltk.word_tokenize(text)
    final_text = ""
    for token in tokens:
        if token in features:
            final_text = final_text + " " + token
    return final_text

#inputfile = 'SignalMediaNewsOnlyHealth.txt'
training_file = input("What is the name of training file?: ")
#outputname = "SignalMediaNewsOnlyHealthTFIDFWholeFeatures.txt"

training_file = codecs.open(training_file, "r", encoding = 'utf-8', errors='replace')
lines = training_file.readlines()

features_file = input("what is the file name for features?: ")
#outputname = "SignalMediaNewsOnlyHealthTFIDFWholeFeatures.txt"

features_file = codecs.open(features_file, "r", encoding = 'utf-8', errors='replace')
features_lines = features_file.readlines()

features = []

for line in features_lines:
    features.append(line.rstrip())

titles = []
targets = []

for line in lines :
    temp = line.rstrip().split("\t")
    #text = temp[2]
    text = filter_features(temp[1], features)
    lowers = text.lower()
    titles.append(lowers)
    targets.append(temp[2])

#titles.pop(0)
#targets.pop(0)

from sklearn.feature_extraction.text import CountVectorizer
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(titles)
#print(X_train_counts.shape)

from sklearn.feature_extraction.text import TfidfTransformer
tf_transformer = TfidfTransformer(use_idf=False).fit(X_train_counts)
X_train_tf = tf_transformer.transform(X_train_counts)
#print(X_train_tf.shape)

tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
#print(X_train_tfidf.shape)

from sklearn.naive_bayes import MultinomialNB
clf = MultinomialNB().fit(X_train_tfidf, targets)

import numpy as np

testing_file = input("What is the name of test file?: ")
testing_file = codecs.open(testing_file, "r", encoding = 'utf-8', errors='replace')
testing_lines = testing_file.readlines()

testing_titles = []
testing_targets = []

for line in testing_lines :
    temp = line.rstrip().split("\t")
    #text = temp[2]
    text = filter_features(temp[1], features)
    lowers = text.lower()
    testing_titles.append(lowers)
    testing_targets.append(temp[2])

#testing_titles.pop(0)
#testing_targets.pop(0)

X_new_counts = count_vect.transform(testing_titles)
X_new_tfidf = tfidf_transformer.transform(X_new_counts)

predicted = clf.predict(X_new_tfidf)

prediction_results = []
prediction_title = ["text", "org_class", "predicted_class"]
prediction_results.append(prediction_title)

for doc, real_category, predicted_category in zip(testing_titles, testing_targets, predicted):
    temp_list = []
    print('%r => %s' % (doc, predicted_category))
    temp_list.append(doc)
    temp_list.append(real_category)
    temp_list.append(predicted_category)
    prediction_results.append(temp_list)

print(np.mean(predicted == testing_targets))

ofile  = codecs.open('classification_results.csv', "wb", encoding="utf-8")
writer = csv.writer(ofile)
writer.writerows(prediction_results)
#!/usr/bin/env python

### NOTE: USE THE CLINICAL TRIAL DATABASE TO CHECK ON CURRENT STATUS OF THESE DRUGS IN ASSOC WITH BREAST CANCER

from Bio import Entrez

# term_list_file = open("/Users/mpillai/Documents/PhD/Wu_Lab/drugs.csv", "r")
# terms = term_list_file.read().split("\n")

# #take list of terms and convert to "term" AND "breast cancer"
# terms1 = []
# for term in terms:
# 	term1 = '"' + term + '"'
# 	terms1.append(term1)

def main():
    search_keyword_1 = input(
        "What is the first MeSH keyword you want to search? (Please search MeSH term at https://meshb.nlm.nih.gov/search: ")
    search_keyword_2 = input(
        "What is the second MeSH keyword you want to search? (Please search MeSH term at https://meshb.nlm.nih.gov/search: ")

    label = search_keyword_1.replace(" ", "_")

    # search_keyword_2 = input("What is the second MeSH keyword you want to search?:")
    Entrez.email = input("What is your email address?:")
    size_data = int(input("How many data instances you like to have in total for training and testing? Please type in integer: "))
    loop = True
    while (loop) :
        type = input("What would you like to extract from PubMed? (e.g., title or abstract): ")
        if (type == "title") or (type == "abstract") :
            loop = False
        else :
            print("""The input you made should be between "title" or "abstract". Please try one more time.""")
    search_keyword_1 = search_keyword_1.replace(" ", "+") + """[MeSH+Terms]"""
    handle = Entrez.esearch(db='pubmed', term=search_keyword_1, retmax= int(size_data * 2.5))
    record = Entrez.read(handle)
    # print(record['IdList'])
    record_ids = record['IdList']

    first_paper_abstract = dict()
    for pmid in record_ids:
        try:
            handle = Entrez.efetch(db='pubmed', id=pmid, retmode='xml')
            records = Entrez.read(handle)
            handle.close()
            pm_id = str(records["PubmedArticle"][0]["MedlineCitation"]["PMID"])
            title = str(records["PubmedArticle"][0]["MedlineCitation"]["Article"]["ArticleTitle"])
            abstract = ""
            if len(records["PubmedArticle"][0]["MedlineCitation"]["Article"]["Abstract"]["AbstractText"]) > 1 :
                for sentence in records["PubmedArticle"][0]["MedlineCitation"]["Article"]["Abstract"]["AbstractText"]:
                    abstract += str(sentence) + " "
            else:
                abstrct = str(records["PubmedArticle"][0]["MedlineCitation"]["Article"]["Abstract"]["AbstractText"])
            if len(abstract) > 50:
                first_paper_abstract[pm_id] = [title, abstract.rstrip(), label]
        except IndexError:
            print("There is no data found")
            pass
        except Exception as err:
            print(err)
            print("We have an error while processing PMID: ",
                  str(records["PubmedArticle"][0]["MedlineCitation"]["PMID"]))
            pass

    label = search_keyword_2.replace(" ", "_")
    search_keyword_2 = search_keyword_2.replace(" ", "+") + """[MeSH+Terms]"""
    handle = Entrez.esearch(db='pubmed', term=search_keyword_2, retmax=int(size_data * 2.5))
    record = Entrez.read(handle)
    # print(record['IdList'])
    record_ids = record['IdList']
    second_paper_abstract = dict()
    for pmid in record_ids:
        try:
            handle = Entrez.efetch(db='pubmed', id=pmid, retmode='xml')
            records = Entrez.read(handle)
            handle.close()
            pm_id = str(records["PubmedArticle"][0]["MedlineCitation"]["PMID"])
            title = str(records["PubmedArticle"][0]["MedlineCitation"]["Article"]["ArticleTitle"])
            abstract = ""
            if len(records["PubmedArticle"][0]["MedlineCitation"]["Article"]["Abstract"]["AbstractText"]) > 1:
                for sentence in records["PubmedArticle"][0]["MedlineCitation"]["Article"]["Abstract"]["AbstractText"]:
                    abstract += str(sentence) + " "
            else:
                abstrct = str(records["PubmedArticle"][0]["MedlineCitation"]["Article"]["Abstract"]["AbstractText"])
            if len(abstract) > 50:
                second_paper_abstract[pm_id] = [title, abstract.rstrip(), label]
        except IndexError:
            print("There is no data found")
            pass
        except Exception as err:
            print(err)
            print("We have an error while processing PMID: ",
                  str(records["PubmedArticle"][0]["MedlineCitation"]["PMID"]))
            pass
    f_training = open('training.txt', 'wb')
    f_testing = open('testing.txt', 'wb')
    num = 0
    outline = "pm_id\ttext\tclass\n"
    f_training.write(outline.encode("utf-8", errors="ignore"))
    f_testing.write(outline.encode("utf-8", errors="ignore"))
    for key in first_paper_abstract.keys():
        if (num <size_data/2) and (num%2 == 0) :
            if type == "title":
                outline = str(key) + "\t" + str(first_paper_abstract[key][0].replace("\t", " ").replace("\r", " ").replace("\n", " ")) + "\t" + str(first_paper_abstract[key][2]) + "\n"
            else :
                outline = str(key) + "\t" + str(first_paper_abstract[key][1].replace("\t", " ").replace("\r", " ").replace("\n", " ")) + "\t" + str(first_paper_abstract[key][2]) + "\n"
            f_training.write(outline.encode("utf-8", errors="ignore"))
        elif (num <size_data/2) and (num%2 == 1):
            if type == "title":
                outline = str(key) + "\t" + str(first_paper_abstract[key][0].replace("\t", " ").replace("\r"," ").replace("\n"," ")) + "\t" + str(first_paper_abstract[key][2]) + "\n"
            else:
                outline = str(key) + "\t" + str(first_paper_abstract[key][1].replace("\t", " ").replace("\r", " ").replace("\n", " ")) + "\t" + str(first_paper_abstract[key][2]) + "\n"
            f_testing.write(outline.encode("utf-8", errors="ignore"))
        num += 1
    num = 0
    for key in second_paper_abstract.keys():
        if (num < size_data/2) and (num % 2 == 0):
            if type == "title":
                outline = str(key) + "\t" + str(second_paper_abstract[key][0].replace("\t", " ").replace("\r"," ").replace("\n"," ")) + "\t" + str(second_paper_abstract[key][2]) + "\n"
            else :
                outline = str(key) + "\t" + str(second_paper_abstract[key][1].replace("\t", " ").replace("\r", " ").replace("\n"," ")) + "\t" + str(second_paper_abstract[key][2]) + "\n"
            f_training.write(outline.encode("utf-8", errors="ignore"))
        elif (num < size_data/2 and num % 2 == 1):
            if type == "title":
                outline = str(key) + "\t" + str(second_paper_abstract[key][0].replace("\t", " ").replace("\r"," ").replace("\n"," ")) + "\t" + str(second_paper_abstract[key][2]) + "\n"
            else:
                outline = str(key) + "\t" + str(second_paper_abstract[key][0].replace("\t", " ").replace("\r", " ").replace("\n"," ")) + "\t" + str(second_paper_abstract[key][2]) + "\n"
            f_testing.write(outline.encode("utf-8", errors="ignore"))
        num += 1
    f_training.close()
    f_testing.close()

main()
